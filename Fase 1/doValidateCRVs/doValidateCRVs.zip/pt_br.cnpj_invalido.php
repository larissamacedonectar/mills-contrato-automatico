<?php

$app_strings['cnpj_invalido'] = 'O CNPJ inserido possui menos de 14 dígitos e/ou é inválido.';