<?php

$app_strings['fone_invalido'] = 'O número de telefone deve possuir 10 ou 11 dígitos (DDD incluso).';