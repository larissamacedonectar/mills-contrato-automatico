<?php

$app_strings['cep_invalido'] = 'O CEP deve possuir 8 dígitos.';