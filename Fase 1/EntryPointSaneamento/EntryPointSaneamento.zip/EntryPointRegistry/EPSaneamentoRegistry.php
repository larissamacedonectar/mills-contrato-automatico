<?php
$entry_point_registry['EPSaneamento'] = array(
  'file' => 'custom/Saneamento/EntryPoint/EPSaneamento.php',
  'auth' => false
);
